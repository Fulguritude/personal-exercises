Long description for 42ai test package
