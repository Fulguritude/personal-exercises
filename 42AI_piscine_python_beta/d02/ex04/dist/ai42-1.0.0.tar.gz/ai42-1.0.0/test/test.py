import ai42.loading.ft_progress

lst = range(1000)
for elem in lst:
    #print(ai42.loading.ft_progress(lst))
    print(ft_progress(lst))